package com.example.eee

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
