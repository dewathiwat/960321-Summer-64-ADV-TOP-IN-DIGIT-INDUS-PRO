package com.example.sensor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
