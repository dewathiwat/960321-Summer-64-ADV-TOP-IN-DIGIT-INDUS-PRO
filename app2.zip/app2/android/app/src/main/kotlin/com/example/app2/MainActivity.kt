package com.example.app2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
