package com.example.ig

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
